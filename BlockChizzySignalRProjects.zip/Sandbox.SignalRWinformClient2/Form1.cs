﻿using Microsoft.AspNet.SignalR.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Sandbox.SignalRWinformClient2
{
    public partial class Form1 : Form
    {
        IHubProxy _hub;
        public Form1()
        {
            InitializeComponent();
            string url = @"http://localhost:8080/";
            var connection = new HubConnection(url);
            _hub = connection.CreateHubProxy("TestHub");
            //_hub.On("SomeWillReceive", x => MessageBox.Show(x));
            connection.Start().Wait();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _hub.Invoke("SomeWillReceive", "").Wait();
        }
    }
}
