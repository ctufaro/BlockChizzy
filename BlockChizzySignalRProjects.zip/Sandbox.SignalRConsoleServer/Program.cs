﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using Microsoft.Owin.Cors;
using Microsoft.Owin.Hosting;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sandbox.SignalRConsoleServer
{
    class Program
    {
        //https://www.codeproject.com/Articles/804770/Implementing-SignalR-in-Desktop-Applications
        static void Main(string[] args)
        {
            string url = @"http://localhost:8080/";
            using (WebApp.Start<Startup>(url))
            {
                Console.WriteLine(string.Format("Server running at {0}", url));
                Console.ReadLine();
                //Console.WriteLine("Bomb!!");
                //var context = GlobalHost.ConnectionManager.GetHubContext<TestHub>();
                //context.Clients.All.ReceiveLength("Boom!!");
                //Console.ReadLine();
            }
        }
    }

    [HubName("TestHub")]
    public class TestHub : Hub
    {
        public void DetermineLength(string message)
        {
            Console.WriteLine(message);
            string newMessage = string.Format(@"{0} has a length of: {1}", message, message.Length);
            Clients.All.ReceiveLength(newMessage);
        }

        public void SomeWillReceive(string message)
        {
            Clients.All.SomeWillReceive("Select few will see");
        }
    }

    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.UseCors(CorsOptions.AllowAll);
            app.MapSignalR();
        }
    }
}
